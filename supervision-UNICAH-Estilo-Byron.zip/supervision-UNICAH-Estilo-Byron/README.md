Presentando el proyecto sin comentarios (no completado)
